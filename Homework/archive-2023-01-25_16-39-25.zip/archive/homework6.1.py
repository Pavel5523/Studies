from random import randint
lst = [randint(0, 100) for i in range(20)]
print('Список случайных чисел на 20 элементов:', lst)
print('Сумма элементов списка:', sum(lst))
